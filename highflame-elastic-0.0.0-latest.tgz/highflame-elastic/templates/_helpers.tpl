{{/*
Expand the name of the chart.
*/}}
{{- define "highflame-elastic.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "highflame-elastic.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "highflame-elastic.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "highflame-elastic.labels" -}}
helm.sh/chart: {{ include "highflame-elastic.chart" . }}
{{ include "highflame-elastic.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "highflame-elastic.selectorLabels" -}}
app.kubernetes.io/name: {{ include "highflame-elastic.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
project: highflame
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "highflame-elastic.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "highflame-elastic.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Checksum Annotations
*/}}
{{- define "highflame-elastic.checksums" -}}
checksum/configmap: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
checksum/secrets: {{ include (print $.Template.BasePath "/secrets.yaml") . | sha256sum }}
checksum/file-configmap: {{ include (print $.Template.BasePath "/file-configmap.yaml") . | sha256sum }}
checksum/file-secrets: {{ include (print $.Template.BasePath "/file-secrets.yaml") . | sha256sum }}
{{- end }}