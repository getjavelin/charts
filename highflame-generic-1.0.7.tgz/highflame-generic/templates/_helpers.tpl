{{/*
Expand the name of the chart.
*/}}
{{- define "highflame-generic.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "highflame-generic.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "highflame-generic.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "highflame-generic.labels" -}}
helm.sh/chart: {{ include "highflame-generic.chart" . }}
{{ include "highflame-generic.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "highflame-generic.selectorLabels" -}}
app.kubernetes.io/name: {{ .Release.Name }}
project: highflame
{{- end }}

{{/*
Bootstrap labels
*/}}
{{- define "highflame-generic.bootstrapLabels" -}}
helm.sh/chart: {{ include "highflame-generic.chart" . }}
{{ include "highflame-generic.bootstrapSelectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector Bootstrap labels
*/}}
{{- define "highflame-generic.bootstrapSelectorLabels" -}}
app.kubernetes.io/name: {{ include "highflame-generic.name" . }}-bootstrap
project: highflame
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "highflame-generic.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "highflame-generic.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Checksum Annotations
*/}}
{{- define "highflame-generic.checksums" -}}
checksum/configmap: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
checksum/secrets: {{ include (print $.Template.BasePath "/secrets.yaml") . | sha256sum }}
checksum/file-configmap: {{ include (print $.Template.BasePath "/file-configmap.yaml") . | sha256sum }}
checksum/file-secrets: {{ include (print $.Template.BasePath "/file-secrets.yaml") . | sha256sum }}
{{- end }}