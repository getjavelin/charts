{{/*
Expand the name of the chart.
*/}}
{{- define "highflame-redteam.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "highflame-redteam.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "highflame-redteam.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "highflame-redteam.labels" -}}
helm.sh/chart: {{ include "highflame-redteam.chart" . }}
{{ include "highflame-redteam.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "highflame-redteam.selectorLabels" -}}
app.kubernetes.io/name: {{ include "highflame-redteam.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
project: highflame
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "highflame-redteam.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "highflame-redteam.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Common worker labels
*/}}
{{- define "highflame-redteam.workerLabels" -}}
helm.sh/chart: {{ include "highflame-redteam.chart" . }}
{{ include "highflame-redteam.workerSelectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector worker labels
*/}}
{{- define "highflame-redteam.workerSelectorLabels" -}}
app.kubernetes.io/name: {{ include "highflame-redteam.name" . }}-worker
app.kubernetes.io/instance: {{ .Release.Name }}-worker
project: highflame
{{- end }}

{{/*
Bootstrap labels
*/}}
{{- define "highflame-redteam.bootstrapLabels" -}}
helm.sh/chart: {{ include "highflame-redteam.chart" . }}
{{ include "highflame-redteam.bootstrapSelectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector Bootstrap labels
*/}}
{{- define "highflame-redteam.bootstrapSelectorLabels" -}}
app.kubernetes.io/name: {{ include "highflame-redteam.name" . }}-bootstrap
project: highflame
{{- end }}

{{/*
Palisade worker labels
*/}}
{{- define "highflame-redteam.palisadeWorkerLabels" -}}
helm.sh/chart: {{ include "highflame-redteam.chart" . }}
{{ include "highflame-redteam.palisadeWorkerSelectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector Palisade worker labels
*/}}
{{- define "highflame-redteam.palisadeWorkerSelectorLabels" -}}
app.kubernetes.io/name: {{ include "highflame-redteam.name" . }}-palisade-worker
app.kubernetes.io/instance: {{ .Release.Name }}-palisade-worker
project: highflame
{{- end }}

{{/*
Checksum Annotations
*/}}
{{- define "highflame-redteam.checksums" -}}
checksum/configmap: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
checksum/secrets: {{ include (print $.Template.BasePath "/secrets.yaml") . | sha256sum }}
checksum/file-configmap: {{ include (print $.Template.BasePath "/file-configmap.yaml") . | sha256sum }}
checksum/file-secrets: {{ include (print $.Template.BasePath "/file-secrets.yaml") . | sha256sum }}
{{- end }}